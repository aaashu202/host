import os



# Required Variables Config
API_ID = int(os.environ.get("API_ID", "23864777"))
API_HASH = os.environ.get("API_HASH", "1ad9abca4b87cee505e4ed3b1a811665")
BOT_TOKEN = os.environ.get("BOT_TOKEN", "7709873308:AAFgTIRICu21vm6EKyNTzvT7SYrf7bzjqeo")
ADMIN = int(os.environ.get("ADMIN", "6710996831"))


# Premium 4GB Renaming Client Config
STRING_SESSION = os.environ.get("STRING_SESSION", "BQHER5IAULbCUTvl4Lmx2Zs1nPbYyiNJ2jN3ngAjbPWRbh3dhl3mxt5Rq88GUz_ERDMkP6kKJFd1g9mdxx18yCXSYr58CdIoK7gfAVdqKRLwtwBEnp26sH8gYSEtXlops3GCwuyzlCGauKxYnBp341hiaUV16PbUJBhlt1NBRSVkZSgEJBVKNIt8z7hE7mrabZvBx6oC2UzxM7UdCrNfSUfh3kkEO1DxBRriWDcyC4WeXRtIk8nA_JzH2nA_1UOsyqu_cUyXBAbTre9QHOwdivlniLaMX8fymbrcSeBovYkGe8wkmHvS4N7-2MYzSX0SeRAhEfNFKpGFo1vHhxc3NvLXyupujgAAAAGPuDEGAA")


# Log & Force Channel Config
FORCE_SUBS = os.environ.get("FORCE_SUBS", "-1002082897235")
LOG_CHANNEL = int(os.environ.get("LOG_CHANNEL", "-1002063983487"))


# Mongo DB Database Config
DATABASE_URL = os.environ.get("DATABASE_URL", "mongodb+srv://STRenameBot:STRenameBot@cluster0.p7bubb0.mongodb.net/?retryWrites=true&w=majority")
DATABASE_NAME = os.environ.get("DATABASE_NAME", "madflixbotz")


# Other Variables Config
START_PIC = os.environ.get("START_PIC", "https://envs.sh/2cI.jpg")





# If You Need To Add Verify System Then Message Me On Telegram
# Check Demo Bots
# https://t.me/FileRenameXBot
# https://t.me/PremiumRenamerRobot
# https://t.me/FileRenamerXRobot
# Token Verification Adding Features Is Paid So If You Want Then Dm Me


# SHORTNER_URL = os.environ.get("SHORTNER_URL", "")
# SHORTNER_API = os.environ.get("SHORTNER_API", "")
# TOKEN_TIMEOUT = os.environ.get("TOKEN_TIMEOUT", "")




# Jishu Developer 
# Don't Remove Credit 🥺
# Telegram Channel @Madflix_Bots
# Backup Channel @JishuBotz
# Developer @JishuDeveloper
